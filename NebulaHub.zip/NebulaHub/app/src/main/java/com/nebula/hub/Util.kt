package com.nebula.hub

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit

/**
 * Uma única thread de fundo que MORRE quando fica ociosa por 5 s.
 * Assim, com o app em segundo plano, não sobra nenhuma thread extra viva.
 */
object Bg {
    private val exec = ThreadPoolExecutor(0, 1, 5, TimeUnit.SECONDS, LinkedBlockingQueue())
    val main = Handler(Looper.getMainLooper())

    fun run(task: () -> Unit) = exec.execute(task)
    fun ui(task: () -> Unit) {
        main.post(task)
    }
}

/** Cache pequeno (máx. 3 MB) de ícones já convertidos para bitmap no tamanho exibido. */
object IconCache {
    private val cache = object : LruCache<String, Bitmap>(3 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }

    fun get(pkg: String): Bitmap? = cache.get(pkg)

    fun load(ctx: Context, pkg: String, sizePx: Int): Bitmap? = try {
        val d = ctx.packageManager.getApplicationIcon(pkg)
        val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, sizePx, sizePx)
        d.draw(Canvas(bmp))
        cache.put(pkg, bmp)
        bmp
    } catch (e: Exception) {
        null
    }

    fun put(key: String, bmp: Bitmap) {
        cache.put(key, bmp)
    }

    fun remove(key: String) {
        cache.remove(key)
    }

    fun clear() = cache.evictAll()
}

/** Preferências simples (SharedPreferences, sem bibliotecas). */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("nebula", Context.MODE_PRIVATE)

    private fun set(c: Context, key: String): HashSet<String> =
        sp(c).getStringSet(key, null)?.let { HashSet(it) } ?: HashSet()

    fun added(c: Context) = set(c, "added")
    fun hidden(c: Context) = set(c, "hidden")

    fun addGame(c: Context, pkg: String) {
        val a = added(c).apply { add(pkg) }
        val h = hidden(c).apply { remove(pkg) }
        sp(c).edit().putStringSet("added", a).putStringSet("hidden", h).apply()
    }

    fun removeGame(c: Context, pkg: String) {
        val a = added(c).apply { remove(pkg) }
        val h = hidden(c).apply { add(pkg) }
        sp(c).edit().putStringSet("added", a).putStringSet("hidden", h).apply()
    }

    fun lastPlayed(c: Context, pkg: String) = sp(c).getLong("played_$pkg", 0L)
    fun markPlayed(c: Context, pkg: String) =
        sp(c).edit().putLong("played_$pkg", System.currentTimeMillis()).apply()

    fun autoPopup(c: Context) = sp(c).getBoolean("auto_popup", false)
    fun setAutoPopup(c: Context, v: Boolean) = sp(c).edit().putBoolean("auto_popup", v).apply()

    /** Modo sem bolha: nada fica sobre o jogo até o painel ser aberto (melhor FPS). */
    fun noBubble(c: Context) = sp(c).getBoolean("no_bubble", false)
    fun setNoBubble(c: Context, v: Boolean) = sp(c).edit().putBoolean("no_bubble", v).apply()

    fun panelAlpha(c: Context) = sp(c).getFloat("panel_alpha", 0.9f)
    fun setPanelAlpha(c: Context, v: Float) = sp(c).edit().putFloat("panel_alpha", v).apply()

    fun bubbleX(c: Context) = sp(c).getInt("bubble_x", -1)
    fun bubbleY(c: Context) = sp(c).getInt("bubble_y", -1)
    fun setBubblePos(c: Context, x: Int, y: Int) =
        sp(c).edit().putInt("bubble_x", x).putInt("bubble_y", y).apply()
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
