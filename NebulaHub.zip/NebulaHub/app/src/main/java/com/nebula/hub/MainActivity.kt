package com.nebula.hub

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ComponentCallbacks2
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.WindowInsets
import android.widget.GridView
import android.widget.ImageButton
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var media: MediaHelper
    private lateinit var player: PlayerViews
    private lateinit var adapter: GameAdapter
    private lateinit var countView: TextView
    private lateinit var accessHint: TextView
    private lateinit var overlayBtn: ImageButton
    private lateinit var autoSwitch: Switch
    private var others: List<Game> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setupEdgeToEdge(findViewById<View>(R.id.root))

        countView = findViewById<TextView>(R.id.game_count)
        accessHint = findViewById<TextView>(R.id.access_hint)
        overlayBtn = findViewById<ImageButton>(R.id.btn_overlay)
        autoSwitch = findViewById<Switch>(R.id.switch_auto)

        // --- música
        val card = findViewById<View>(R.id.player_card)
        media = MediaHelper(this) { s ->
            player.render(s)
            accessHint.visibility = if (s.hasAccess) View.GONE else View.VISIBLE
        }
        player = PlayerViews(card, media)
        findViewById<View>(R.id.track_info).setOnClickListener {
            if (media.hasAccess()) Spotify.open(this) else askMediaAccess()
        }
        accessHint.setOnClickListener { askMediaAccess() }
        findViewById<View>(R.id.btn_liked).setOnClickListener {
            Spotify.openUri(this, "spotify:collection:tracks")
        }

        // --- pop-up
        overlayBtn.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                askOverlayPermission()
            } else {
                renderOverlayButton(OverlayService.toggle(this))
            }
        }
        autoSwitch.isChecked = Prefs.autoPopup(this)
        autoSwitch.setOnCheckedChangeListener { _, checked ->
            Prefs.setAutoPopup(this, checked)
            if (checked && !Settings.canDrawOverlays(this)) askOverlayPermission()
        }

        // --- jogos
        adapter = GameAdapter(this)
        val grid = findViewById<GridView>(R.id.grid)
        grid.adapter = adapter
        grid.emptyView = findViewById<View>(R.id.empty)
        grid.setOnItemClickListener { _, _, pos, _ -> launch(adapter.getItem(pos)) }
        grid.setOnItemLongClickListener { _, _, pos, _ ->
            showGameOptions(adapter.getItem(pos)); true
        }
        findViewById<View>(R.id.btn_add).setOnClickListener { showAddDialog() }

        loadGames()
    }

    override fun onStart() {
        super.onStart()
        media.start()                       // escuta a música só com a tela visível
        renderOverlayButton(OverlayService.isRunning)
    }

    override fun onStop() {
        media.stop()                        // em segundo plano: nenhum listener ativo
        super.onStop()
    }

    override fun onRestart() {
        super.onRestart()
        loadGames()                         // pega jogos instalados enquanto o app estava fechado
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        // App saiu da tela: devolve ao sistema a memória dos ícones
        if (level >= ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN) IconCache.clear()
    }

    // ---------------------------------------------------------------- jogos

    private fun loadGames() {
        val app = applicationContext
        Bg.run {
            val r = GameRepository.load(app)
            Bg.ui {
                if (isDestroyed) return@ui
                adapter.submit(r.games)
                others = r.others
                countView.text = r.games.size.toString()
            }
        }
    }

    private fun launch(g: Game) {
        val i = packageManager.getLaunchIntentForPackage(g.pkg)
        if (i == null) {
            Toast.makeText(this, R.string.cannot_launch, Toast.LENGTH_SHORT).show()
            return
        }
        Prefs.markPlayed(this, g.pkg)
        if (Prefs.autoPopup(this) && Settings.canDrawOverlays(this) && !OverlayService.isRunning) {
            OverlayService.start(this)
        }
        try {
            startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, R.string.cannot_launch, Toast.LENGTH_SHORT).show()
        }
    }

    private fun showGameOptions(g: Game) {
        val opts = arrayOf(getString(R.string.opt_play), getString(R.string.opt_remove), getString(R.string.opt_info))
        AlertDialog.Builder(this)
            .setTitle(g.label)
            .setItems(opts) { _, which ->
                when (which) {
                    0 -> launch(g)
                    1 -> {
                        Prefs.removeGame(this, g.pkg); loadGames()
                    }
                    2 -> safeStart(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${g.pkg}"))
                    )
                }
            }
            .show()
    }

    private fun showAddDialog() {
        val list = others
        if (list.isEmpty()) {
            Toast.makeText(this, R.string.nothing_to_add, Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.add_dialog_title)
            .setItems(list.map { it.label }.toTypedArray()) { _, which ->
                Prefs.addGame(this, list[which].pkg)
                loadGames()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    // ---------------------------------------------------------------- permissões

    private fun askOverlayPermission() {
        AlertDialog.Builder(this)
            .setTitle(R.string.perm_overlay_title)
            .setMessage(R.string.perm_overlay_msg)
            .setPositiveButton(R.string.allow) { _, _ ->
                safeStart(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun askMediaAccess() {
        AlertDialog.Builder(this)
            .setTitle(R.string.perm_media_title)
            .setMessage(R.string.perm_media_msg)
            .setPositiveButton(R.string.allow) { _, _ ->
                val opened = Build.VERSION.SDK_INT >= 30 && safeStart(
                    Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS).putExtra(
                        Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME,
                        ComponentName(this, MediaListener::class.java).flattenToString()
                    )
                )
                if (!opened) safeStart(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun safeStart(i: Intent): Boolean = try {
        startActivity(i); true
    } catch (e: ActivityNotFoundException) {
        false
    }

    // ---------------------------------------------------------------- visual

    private fun renderOverlayButton(on: Boolean) {
        overlayBtn.isSelected = on
        overlayBtn.alpha = if (on) 1f else 0.6f
        overlayBtn.imageTintList = getColorStateList(if (on) R.color.neon_soft else R.color.text)
    }

    @Suppress("DEPRECATION")
    private fun setupEdgeToEdge(root: View) {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
        } else {
            root.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
        root.setOnApplyWindowInsetsListener { v, insets ->
            if (Build.VERSION.SDK_INT >= 30) {
                val b = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
                v.setPadding(b.left, b.top, b.right, b.bottom)
            } else {
                v.setPadding(
                    insets.systemWindowInsetLeft, insets.systemWindowInsetTop,
                    insets.systemWindowInsetRight, insets.systemWindowInsetBottom
                )
            }
            insets
        }
    }
}
