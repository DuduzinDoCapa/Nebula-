package com.nebula.hub

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.SystemClock
import android.provider.Settings
import android.view.KeyEvent

/**
 * Controla o Spotify (ou o player ativo) via MediaSession do próprio Android.
 *
 * - Não precisa de conta de desenvolvedor do Spotify nem de SDK externo.
 * - 100% orientado a eventos: nenhuma consulta periódica (polling).
 * - Só escuta enquanto alguma tela está visível (start/stop). Em segundo plano: zero trabalho.
 * - playUri(): toca uma playlist sem abrir o Spotify. Se ele estiver fechado, é
 *   acordado em segundo plano pela tecla de mídia do sistema.
 */
class MediaHelper(context: Context, private val onUpdate: (State) -> Unit) {

    data class State(
        val hasAccess: Boolean,
        val title: String? = null,
        val artist: String? = null,
        val art: Bitmap? = null,
        val playing: Boolean = false,
        val isSpotify: Boolean = false,
    )

    private val ctx = context.applicationContext
    private val msm = ctx.getSystemService(MediaSessionManager::class.java)
    private val audio = ctx.getSystemService(AudioManager::class.java)
    private val listener = ComponentName(ctx, MediaListener::class.java)
    private var controller: MediaController? = null
    private var listening = false     // listeners registrados no sistema
    private var visible = false       // alguma tela quer receber atualizações
    private var lastState: State? = null

    // Playlist pedida enquanto o Spotify ainda não tinha sessão ativa
    private var pendingUri: String? = null
    // Comando enviado; aguardando a música mudar para confirmar
    private var verifyUri: String? = null
    private var verifyTitle: String? = null

    private val timeout = Runnable {
        val uri = pendingUri ?: verifyUri
        pendingUri = null
        verifyUri = null
        // Só abre o Spotify como último recurso, e nunca se a tela já saiu (para não tirar você do jogo)
        if (uri != null && visible) Spotify.openUri(ctx, uri)
        if (!visible) release()
    }

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = publish()
        override fun onPlaybackStateChanged(state: PlaybackState?) = publish()
        override fun onQueueTitleChanged(title: CharSequence?) = confirm()
        override fun onSessionDestroyed() {
            bind(null)
        }
    }

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> pick(list) }

    fun hasAccess(): Boolean {
        val enabled = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners")
        return enabled?.contains(listener.flattenToString()) == true ||
            enabled?.contains(listener.flattenToShortString()) == true
    }

    fun start() {
        visible = true
        lastState = null
        if (listening) {
            publish()
            return
        }
        if (!hasAccess()) {
            onUpdate(State(hasAccess = false))
            return
        }
        try {
            msm.addOnActiveSessionsChangedListener(sessionsListener, listener, Bg.main)
            listening = true
            pick(msm.getActiveSessions(listener))
        } catch (e: SecurityException) {
            onUpdate(State(hasAccess = false))
        }
    }

    fun stop() {
        visible = false
        // Se uma playlist acabou de ser pedida, continua ouvindo só até ela começar.
        if (pendingUri == null && verifyUri == null) release()
    }

    private fun release() {
        Bg.main.removeCallbacks(timeout)
        pendingUri = null
        verifyUri = null
        if (listening) {
            try {
                msm.removeOnActiveSessionsChangedListener(sessionsListener)
            } catch (_: Exception) {
            }
            listening = false
        }
        controller?.unregisterCallback(callback)
        controller = null
        lastState = null
    }

    private fun pick(list: List<MediaController>?) {
        if (!listening) return
        val spotify = list?.firstOrNull { it.packageName == Spotify.PKG }
        val c = spotify
            ?: list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list?.firstOrNull()
        bind(c)
        val p = pendingUri
        if (p != null && spotify != null) send(spotify, p)
    }

    private fun bind(c: MediaController?) {
        val old = controller
        if (c != null && old != null && c.sessionToken == old.sessionToken) {
            publish()
            return
        }
        old?.unregisterCallback(callback)
        controller = c
        c?.registerCallback(callback, Bg.main)
        publish()
    }

    private fun publish() {
        val c = controller
        val s = if (c == null) State(hasAccess = true) else {
            val m = c.metadata
            val st = c.playbackState?.state
            State(
                hasAccess = true,
                title = m?.getString(MediaMetadata.METADATA_KEY_TITLE),
                artist = m?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                    ?: m?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST),
                art = m?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                    ?: m?.getBitmap(MediaMetadata.METADATA_KEY_ART)
                    ?: m?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON),
                playing = st == PlaybackState.STATE_PLAYING || st == PlaybackState.STATE_BUFFERING,
                isSpotify = c.packageName == Spotify.PKG,
            )
        }
        if (verifyUri != null && s.isSpotify && s.title != null && s.title != verifyTitle) confirm()
        if (!visible || s == lastState) return   // evita redesenhar a tela à toa
        lastState = s
        onUpdate(s)
    }

    private fun confirm() {
        if (verifyUri == null) return
        verifyUri = null
        Bg.main.removeCallbacks(timeout)
        if (!visible) release()
    }

    // ---------------------------------------------------------------- comandos

    /** Toca uma playlist/álbum (spotify:playlist:...) sem abrir o Spotify. */
    fun playUri(uri: String) {
        if (!listening || !hasAccess()) {
            Spotify.openUri(ctx, uri)
            return
        }
        Bg.main.removeCallbacks(timeout)
        val c = spotifyController()
        if (c != null) {
            send(c, uri)
        } else {
            // Spotify fechado: acorda pelo sistema (sem abrir a tela) e espera a sessão aparecer
            pendingUri = uri
            sendKey(KeyEvent.KEYCODE_MEDIA_PLAY)
            Bg.main.postDelayed(timeout, 7000)
        }
    }

    private fun spotifyController(): MediaController? =
        controller?.takeIf { it.packageName == Spotify.PKG } ?: try {
            msm.getActiveSessions(listener).firstOrNull { it.packageName == Spotify.PKG }
        } catch (e: SecurityException) {
            null
        }

    private fun send(c: MediaController, uri: String) {
        pendingUri = null
        verifyUri = uri
        verifyTitle = c.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
        val actions = c.playbackState?.actions ?: 0L
        val byUri = actions and PlaybackState.ACTION_PLAY_FROM_URI != 0L
        val byId = actions and PlaybackState.ACTION_PLAY_FROM_MEDIA_ID != 0L
        if (byId && !byUri) {
            c.transportControls.playFromMediaId(uri, null)
        } else {
            c.transportControls.playFromUri(Uri.parse(uri), null)
        }
        Bg.main.removeCallbacks(timeout)
        Bg.main.postDelayed(timeout, 5000)
    }

    fun playPause() {
        val c = controller
        if (c == null) {
            // Sem sessão ativa: manda a tecla "play" para o último player usado (normalmente o Spotify).
            sendKey(KeyEvent.KEYCODE_MEDIA_PLAY)
            return
        }
        val st = c.playbackState?.state
        if (st == PlaybackState.STATE_PLAYING || st == PlaybackState.STATE_BUFFERING) {
            c.transportControls.pause()
        } else {
            c.transportControls.play()
        }
    }

    fun next() {
        controller?.transportControls?.skipToNext() ?: sendKey(KeyEvent.KEYCODE_MEDIA_NEXT)
    }

    fun previous() {
        controller?.transportControls?.skipToPrevious() ?: sendKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
    }

    private fun sendKey(code: Int) {
        val t = SystemClock.uptimeMillis()
        audio.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0))
        audio.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0))
    }
}
