package com.nebula.hub

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri

object Spotify {
    const val PKG = "com.spotify.music"

    /** Abre o Spotify; se não estiver instalado, abre a página dele na Play Store. */
    fun open(ctx: Context) {
        val launch = ctx.packageManager.getLaunchIntentForPackage(PKG)
        if (launch != null) {
            start(ctx, launch)
        } else {
            openStore(ctx)
        }
    }

    /** Abre uma tela específica do Spotify (ex.: "spotify:collection:tracks" = Músicas Curtidas). */
    fun openUri(ctx: Context, uri: String) {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(uri)).setPackage(PKG)
        if (!start(ctx, i)) open(ctx)
    }

    private fun openStore(ctx: Context) {
        if (!start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$PKG")))) {
            start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$PKG")))
        }
    }

    private fun start(ctx: Context, i: Intent): Boolean = try {
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: ActivityNotFoundException) {
        false
    } catch (e: SecurityException) {
        false
    }
}
