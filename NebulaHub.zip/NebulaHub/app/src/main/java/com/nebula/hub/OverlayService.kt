package com.nebula.hub

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.service.quicksettings.TileService
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.SeekBar
import kotlin.math.abs

/**
 * Pop-up translúcido sobre os jogos.
 *
 * Economia de recursos:
 * - Só existe enquanto o pop-up está ligado (START_NOT_STICKY: o sistema não o recria sozinho).
 * - Minimizado (só a bolha): nenhum listener, nenhum timer, nenhuma animação — CPU em 0%.
 * - O painel só escuta a música enquanto está aberto; ao minimizar, solta tudo (inclusive a capa).
 * - Sem desfoque em tempo real (blur custa GPU a cada frame); a translucidez é só alfa.
 */
class OverlayService : Service() {

    companion object {
        @Volatile
        var isRunning = false
            private set

        private const val CHANNEL = "overlay"
        private const val NOTIF_ID = 7
        private const val ACTION_STOP = "com.nebula.hub.action.STOP_OVERLAY"
        private const val BUBBLE_IDLE_ALPHA = 0.55f

        /** Retorna false se não tiver permissão ou se o sistema bloquear o início agora. */
        fun start(ctx: Context): Boolean {
            if (!Settings.canDrawOverlays(ctx)) return false
            return try {
                ctx.startForegroundService(Intent(ctx, OverlayService::class.java))
                true
            } catch (e: IllegalStateException) {
                false
            } catch (e: SecurityException) {
                false
            }
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, OverlayService::class.java))
        }

        /** Retorna o novo estado esperado (true = ligado). */
        fun toggle(ctx: Context): Boolean = if (isRunning) {
            stop(ctx); false
        } else {
            start(ctx)
        }
    }

    private lateinit var wm: WindowManager
    private lateinit var themed: Context
    private lateinit var media: MediaHelper

    private var bubble: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var panel: View? = null
    private var player: PlayerViews? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WindowManager::class.java)
        themed = ContextThemeWrapper(this, R.style.Theme_Nebula)
        media = MediaHelper(this) { s -> player?.render(s) }

        if (!goForeground() || !Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        isRunning = true
        showBubble()
        refreshTile()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) stopSelf()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        isRunning = false
        media.stop()
        player?.clearArt()
        removeSafely(panel)
        removeSafely(bubble)
        panel = null
        player = null
        bubble = null
        refreshTile()
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // Rotação: mantém a bolha dentro da tela
        val b = bubble
        val p = bubbleParams
        if (b != null && p != null && b.isAttachedToWindow) snapToEdge(b, p)
    }

    // ---------------------------------------------------------------- notificação

    private fun goForeground(): Boolean {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            val ch = NotificationChannel(CHANNEL, getString(R.string.channel_overlay), NotificationManager.IMPORTANCE_MIN)
            ch.setShowBadge(false)
            ch.setSound(null, null)
            ch.enableVibration(false)
            nm.createNotificationChannel(ch)
        }
        val stopPi = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_music)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setContentIntent(stopPi)
            .setOngoing(true)
            .setShowWhen(false)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
        return try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(NOTIF_ID, n)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun refreshTile() {
        try {
            TileService.requestListeningState(this, ComponentName(this, OverlayTileService::class.java))
        } catch (_: Exception) {
        }
    }

    // ---------------------------------------------------------------- bolha

    private fun overlayParams(w: Int, h: Int, extraFlags: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or extraFlags,
        PixelFormat.TRANSLUCENT
    )

    private fun screenSize(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val dm = android.util.DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            dm.widthPixels to dm.heightPixels
        }
    }

    @SuppressLint("ClickableViewAccessibility", "InflateParams")
    private fun showBubble() {
        val existing = bubble
        val existingParams = bubbleParams
        if (existing != null && existingParams != null) {
            if (!existing.isAttachedToWindow) wm.addView(existing, existingParams)
            return
        }

        val size = dp(52)
        val v = LayoutInflater.from(themed).inflate(R.layout.overlay_bubble, null)
        v.alpha = BUBBLE_IDLE_ALPHA
        val (sw, sh) = screenSize()
        val p = overlayParams(size, size, 0).apply {
            gravity = Gravity.TOP or Gravity.START
            val sx = Prefs.bubbleX(this@OverlayService)
            val sy = Prefs.bubbleY(this@OverlayService)
            x = if (sx >= 0) sx.coerceAtMost(sw - size) else sw - size
            y = if (sy >= 0) sy.coerceAtMost(sh - size) else sh / 3
        }

        val slop = ViewConfiguration.get(themed).scaledTouchSlop
        v.setOnTouchListener(object : View.OnTouchListener {
            var downX = 0f
            var downY = 0f
            var startX = 0
            var startY = 0
            var dragging = false

            override fun onTouch(view: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = e.rawX; downY = e.rawY
                        startX = p.x; startY = p.y
                        dragging = false
                        view.alpha = 1f
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - downX
                        val dy = e.rawY - downY
                        if (!dragging && (abs(dx) > slop || abs(dy) > slop)) dragging = true
                        if (dragging) {
                            p.x = startX + dx.toInt()
                            p.y = startY + dy.toInt()
                            updateSafely(view, p)
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        view.alpha = BUBBLE_IDLE_ALPHA
                        if (dragging) snapToEdge(view, p) else openPanel()
                    }
                    MotionEvent.ACTION_CANCEL -> {
                        view.alpha = BUBBLE_IDLE_ALPHA
                        if (dragging) snapToEdge(view, p)
                    }
                }
                return true
            }
        })

        bubble = v
        bubbleParams = p
        wm.addView(v, p)
    }

    /** Encosta a bolha na borda mais próxima (sem animação contínua). */
    private fun snapToEdge(v: View, p: WindowManager.LayoutParams) {
        val (sw, sh) = screenSize()
        val size = p.width
        p.x = if (p.x + size / 2 < sw / 2) 0 else sw - size
        p.y = p.y.coerceIn(0, (sh - size).coerceAtLeast(0))
        updateSafely(v, p)
        Prefs.setBubblePos(this, p.x, p.y)
    }

    // ---------------------------------------------------------------- painel

    @SuppressLint("ClickableViewAccessibility", "InflateParams")
    private fun openPanel() {
        removeSafely(bubble) // a bolha some enquanto o painel está aberto

        val v = panel ?: LayoutInflater.from(themed).inflate(R.layout.overlay_panel, null).also {
            buildPanel(it)
            panel = it
        }
        val (sw, _) = screenSize()
        val p = overlayParams(
            dp(320).coerceAtMost(sw - dp(24)),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(20)
            windowAnimations = android.R.style.Animation_Toast
        }
        v.alpha = Prefs.panelAlpha(this)
        if (!v.isAttachedToWindow) wm.addView(v, p)
        media.start()
    }

    private fun closePanel() {
        media.stop()
        player?.clearArt()
        removeSafely(panel)
        if (isRunning) showBubble()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun buildPanel(v: View) {
        player = PlayerViews(v, media)

        v.findViewById<View>(R.id.btn_collapse).setOnClickListener { closePanel() }
        v.findViewById<View>(R.id.btn_stop).setOnClickListener { stopSelf() }
        v.findViewById<View>(R.id.btn_spotify).setOnClickListener {
            Spotify.open(this) // abre enquanto o painel ainda está visível (exigência do Android 14+)
            closePanel()
        }

        val seek = v.findViewById<SeekBar>(R.id.seek_alpha)
        seek.progress = ((Prefs.panelAlpha(this) - 0.4f) * 100).toInt().coerceIn(0, seek.max)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                v.alpha = 0.4f + progress / 100f
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {
                Prefs.setPanelAlpha(this@OverlayService, v.alpha)
            }
        })

        // Toque fora do painel (no jogo): minimiza e devolve o jogo
        v.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_OUTSIDE) {
                closePanel(); true
            } else false
        }
    }

    // ---------------------------------------------------------------- utilidades

    private fun updateSafely(v: View, p: WindowManager.LayoutParams) {
        try {
            if (v.isAttachedToWindow) wm.updateViewLayout(v, p)
        } catch (_: Exception) {
        }
    }

    private fun removeSafely(v: View?) {
        try {
            if (v != null && v.isAttachedToWindow) wm.removeView(v)
        } catch (_: Exception) {
        }
    }
}
