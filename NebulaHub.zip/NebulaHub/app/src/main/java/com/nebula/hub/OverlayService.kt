package com.nebula.hub

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.service.quicksettings.TileService
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.SeekBar
import kotlin.math.abs

/**
 * Pop-up translúcido sobre os jogos.
 *
 * Desempenho no jogo:
 * - Janelas com aceleração de hardware e transparência aplicada pelo compositor
 *   (alpha da janela, não da View) — nada é redesenhado em software.
 * - A bolha se recolhe meio escondida na borda após 2,5 s: área sobreposta mínima.
 * - "Modo sem bolha": nada fica sobre o jogo; o painel abre pelo bloco rápido e,
 *   ao fechar, o serviço inteiro se encerra.
 * - Minimizado: nenhum listener, timer ou animação. O painel só escuta a música enquanto aberto.
 */
class OverlayService : Service() {

    companion object {
        @Volatile
        var isRunning = false
            private set

        private const val CHANNEL = "overlay"
        private const val NOTIF_ID = 7
        private const val ACTION_STOP = "com.nebula.hub.action.STOP_OVERLAY"
        private const val BUBBLE_ALPHA = 0.7f
        private const val DOCKED_ALPHA = 0.4f
        private const val DOCK_DELAY_MS = 2500L

        /** Retorna false se não tiver permissão ou se o sistema bloquear o início agora. */
        fun start(ctx: Context): Boolean {
            if (!Settings.canDrawOverlays(ctx)) return false
            return try {
                ctx.startForegroundService(Intent(ctx, OverlayService::class.java))
                true
            } catch (e: IllegalStateException) {
                false
            } catch (e: SecurityException) {
                false
            }
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, OverlayService::class.java))
        }

        /** Retorna o novo estado esperado (true = ligado). */
        fun toggle(ctx: Context): Boolean = if (isRunning) {
            stop(ctx); false
        } else {
            start(ctx)
        }
    }

    private lateinit var wm: WindowManager
    private lateinit var themed: Context
    private lateinit var media: MediaHelper

    private var bubble: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var panel: View? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var player: PlayerViews? = null
    private var playlists: PlaylistViews? = null
    private val dockRunnable = Runnable { dock() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WindowManager::class.java)
        themed = ContextThemeWrapper(this, R.style.Theme_Nebula)
        media = MediaHelper(this) { s -> player?.render(s) }

        if (!goForeground() || !Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        isRunning = true
        if (Prefs.noBubble(this)) openPanel() else showBubble()
        refreshTile()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) stopSelf()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        isRunning = false
        Bg.main.removeCallbacks(dockRunnable)
        media.stop()
        player?.clearArt()
        removeSafely(panel)
        removeSafely(bubble)
        panel = null
        player = null
        playlists = null
        bubble = null
        refreshTile()
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val b = bubble
        val p = bubbleParams
        if (b != null && p != null && b.isAttachedToWindow) {
            snapToEdge(b, p)
            scheduleDock()
        }
    }

    // ---------------------------------------------------------------- notificação

    private fun goForeground(): Boolean {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            val ch = NotificationChannel(CHANNEL, getString(R.string.channel_overlay), NotificationManager.IMPORTANCE_MIN)
            ch.setShowBadge(false)
            ch.setSound(null, null)
            ch.enableVibration(false)
            nm.createNotificationChannel(ch)
        }
        val stopPi = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_music)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setContentIntent(stopPi)
            .setOngoing(true)
            .setShowWhen(false)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
        return try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(NOTIF_ID, n)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun refreshTile() {
        try {
            TileService.requestListeningState(this, ComponentName(this, OverlayTileService::class.java))
        } catch (_: Exception) {
        }
    }

    // ---------------------------------------------------------------- bolha

    private fun overlayParams(w: Int, h: Int, extraFlags: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED or
            extraFlags,
        PixelFormat.TRANSLUCENT
    )

    private fun screenSize(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val dm = android.util.DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            dm.widthPixels to dm.heightPixels
        }
    }

    @SuppressLint("ClickableViewAccessibility", "InflateParams")
    private fun showBubble() {
        val existing = bubble
        val existingParams = bubbleParams
        if (existing != null && existingParams != null) {
            if (!existing.isAttachedToWindow) {
                existingParams.alpha = BUBBLE_ALPHA
                wm.addView(existing, existingParams)
            }
            scheduleDock()
            return
        }

        val size = dp(48)
        val v = LayoutInflater.from(themed).inflate(R.layout.overlay_bubble, null)
        val (sw, sh) = screenSize()
        val p = overlayParams(size, size, 0).apply {
            gravity = Gravity.TOP or Gravity.START
            alpha = BUBBLE_ALPHA
            val sx = Prefs.bubbleX(this@OverlayService)
            val sy = Prefs.bubbleY(this@OverlayService)
            x = if (sx >= 0) sx.coerceAtMost(sw - size) else sw - size
            y = if (sy >= 0) sy.coerceAtMost(sh - size) else sh / 3
        }

        val slop = ViewConfiguration.get(themed).scaledTouchSlop
        v.setOnTouchListener(object : View.OnTouchListener {
            var downX = 0f
            var downY = 0f
            var startX = 0
            var startY = 0
            var dragging = false

            override fun onTouch(view: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        Bg.main.removeCallbacks(dockRunnable)
                        undock(view, p)
                        downX = e.rawX; downY = e.rawY
                        startX = p.x; startY = p.y
                        dragging = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - downX
                        val dy = e.rawY - downY
                        if (!dragging && (abs(dx) > slop || abs(dy) > slop)) dragging = true
                        if (dragging) {
                            p.x = startX + dx.toInt()
                            p.y = startY + dy.toInt()
                            updateSafely(view, p)
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (dragging) {
                            snapToEdge(view, p); scheduleDock()
                        } else {
                            openPanel()
                        }
                    }
                    MotionEvent.ACTION_CANCEL -> {
                        snapToEdge(view, p); scheduleDock()
                    }
                }
                return true
            }
        })

        // Pede ao sistema que toques na bolha não virem gesto de "voltar" na borda
        if (Build.VERSION.SDK_INT >= 29) {
            v.addOnLayoutChangeListener { view, l, t, r, b, _, _, _, _ ->
                view.systemGestureExclusionRects = listOf(Rect(0, 0, r - l, b - t))
            }
        }

        bubble = v
        bubbleParams = p
        wm.addView(v, p)
        scheduleDock()
    }

    private fun scheduleDock() {
        Bg.main.removeCallbacks(dockRunnable)
        Bg.main.postDelayed(dockRunnable, DOCK_DELAY_MS)
    }

    /**
     * Recolhe a bolha: encostada na borda e mais transparente.
     * Ela continua inteira na tela — se ficasse metade para fora, a parte visível
     * cairia na faixa do gesto "voltar" do Android e deixaria de responder ao toque.
     */
    private fun dock() {
        val v = bubble ?: return
        val p = bubbleParams ?: return
        if (!v.isAttachedToWindow) return
        val (sw, _) = screenSize()
        p.x = if (p.x + p.width / 2 < sw / 2) 0 else sw - p.width
        p.alpha = DOCKED_ALPHA
        updateSafely(v, p)
    }

    private fun undock(v: View, p: WindowManager.LayoutParams) {
        val (sw, _) = screenSize()
        p.x = p.x.coerceIn(0, (sw - p.width).coerceAtLeast(0))
        p.alpha = 1f
        updateSafely(v, p)
    }

    /** Encosta a bolha na borda mais próxima. */
    private fun snapToEdge(v: View, p: WindowManager.LayoutParams) {
        val (sw, sh) = screenSize()
        val size = p.width
        p.x = if (p.x + size / 2 < sw / 2) 0 else sw - size
        p.y = p.y.coerceIn(0, (sh - size).coerceAtLeast(0))
        p.alpha = BUBBLE_ALPHA
        updateSafely(v, p)
        Prefs.setBubblePos(this, p.x, p.y)
    }

    // ---------------------------------------------------------------- painel

    @SuppressLint("InflateParams")
    private fun openPanel() {
        Bg.main.removeCallbacks(dockRunnable)
        removeSafely(bubble) // a bolha some enquanto o painel está aberto

        val v = panel ?: LayoutInflater.from(themed).inflate(R.layout.overlay_panel, null).also {
            buildPanel(it)
            panel = it
        }
        val (sw, _) = screenSize()
        val p = panelParams ?: overlayParams(
            0,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(16)
            windowAnimations = android.R.style.Animation_Toast
        }.also { panelParams = it }
        p.width = dp(340).coerceAtMost(sw - dp(20))
        p.alpha = Prefs.panelAlpha(this)
        playlists?.refresh()
        if (!v.isAttachedToWindow) wm.addView(v, p)
        media.start()
    }

    private fun closePanel() {
        media.stop()
        player?.clearArt()
        removeSafely(panel)
        if (Prefs.noBubble(this)) {
            stopSelf() // modo sem bolha: nada fica sobre o jogo
        } else if (isRunning) {
            showBubble()
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun buildPanel(v: View) {
        player = PlayerViews(v, media)
        playlists = PlaylistViews(v, media, 52)

        v.findViewById<View>(R.id.btn_collapse).setOnClickListener { closePanel() }
        v.findViewById<View>(R.id.btn_stop).setOnClickListener { stopSelf() }
        v.findViewById<View>(R.id.btn_spotify).setOnClickListener {
            Spotify.open(this) // abre enquanto o painel ainda está visível (exigência do Android 14+)
            closePanel()
        }

        val seek = v.findViewById<SeekBar>(R.id.seek_alpha)
        seek.progress = ((Prefs.panelAlpha(this) - 0.4f) * 100).toInt().coerceIn(0, seek.max)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                val p = panelParams ?: return
                p.alpha = 0.4f + progress / 100f
                updateSafely(v, p)
            }

            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {
                Prefs.setPanelAlpha(this@OverlayService, 0.4f + sb.progress / 100f)
            }
        })

        // Toque fora do painel (no jogo): minimiza e devolve o jogo
        v.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_OUTSIDE) {
                closePanel(); true
            } else false
        }
    }

    // ---------------------------------------------------------------- utilidades

    private fun updateSafely(v: View, p: WindowManager.LayoutParams) {
        try {
            if (v.isAttachedToWindow) wm.updateViewLayout(v, p)
        } catch (_: Exception) {
        }
    }

    private fun removeSafely(v: View?) {
        try {
            if (v != null && v.isAttachedToWindow) wm.removeView(v)
        } catch (_: Exception) {
        }
    }
}
