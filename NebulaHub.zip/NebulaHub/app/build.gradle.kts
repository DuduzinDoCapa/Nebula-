plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.nebula.hub"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.nebula.hub"
        minSdk = 26          // Android 8.0+ (necessário para TYPE_APPLICATION_OVERLAY)
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            // R8 encolhe e otimiza o código -> APK menor e menos RAM
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            // Assinado com a chave de debug para facilitar a instalação pessoal.
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        buildConfig = false
    }

    dependenciesInfo {
        includeInApk = false
        includeInBundle = false
    }
}

// Sem dependências externas: só o framework Android + Kotlin stdlib.
// Isso mantém o APK pequeno (~100 KB) e o consumo de RAM baixo.
dependencies {
}
