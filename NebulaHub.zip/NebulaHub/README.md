# Nebula — Game Hub

App Android leve, com visual futurista roxo/preto, para abrir seus jogos e controlar o Spotify, com um **pop-up translúcido flutuante** durante o jogo.

## Funções

- **Biblioteca de jogos**: detecta sozinho os jogos instalados (categoria "Jogo" do Android). Os jogados recentemente ficam primeiro.
  - **+ Adicionar**: inclui qualquer outro app (emuladores, launchers etc.).
  - **Toque longo** num jogo: jogar, remover da lista ou abrir as informações do app.
- **Player do Spotify**: capa, música, artista, anterior / tocar-pausar / próxima e atalho para as **Curtidas**. Toque na música para abrir o Spotify.
- **Pop-up durante o jogo**: uma bolha flutuante translúcida (arraste para mover; ela encosta na borda). Toque para abrir o painel de controle com **opacidade ajustável**. Toque fora do painel para voltar ao jogo.
  - Botão de pop-up no topo do app;
  - Opção **"Abrir pop-up ao iniciar um jogo"**;
  - **Bloco nas Configurações Rápidas** ("Pop-up Nebula"): puxe a barra durante o jogo e toque nele;
  - **Atalho no ícone**: toque longo no ícone do Nebula → "Pop-up".

## Consumo mínimo em segundo plano

| Situação | O que roda |
|---|---|
| App fechado / em segundo plano | **Nada.** Sem serviços, alarmes, timers ou WakeLocks. Os ícones são liberados da memória. |
| Pop-up minimizado (só a bolha) | Uma janela de 52 dp parada. Sem listeners nem animações: **CPU em ~0%**. |
| Painel aberto | Recebe só os *eventos* de mudança de música (sem consulta periódica). Ao minimizar, solta tudo. |

Outras escolhas que deixam o app leve:
- **Zero bibliotecas externas** (nem AndroidX): APK de ~100 KB, otimizado com R8.
- Controle do Spotify pelo **MediaSession do próprio Android**: não precisa de SDK nem conta de desenvolvedor do Spotify.
- O serviço de "acesso a notificações" (exigido pelo Android para controlar a música) **se desliga sozinho** logo após conectar, para não manter o app na memória.
- Translucidez feita só com transparência (sem desfoque em tempo real, que gasta GPU a cada quadro).
- O pop-up não é recriado automaticamente se o sistema o encerrar (`START_NOT_STICKY`).

## Como gerar o APK

### Opção A — GitHub (sem instalar nada)
1. Crie um repositório no GitHub e envie esta pasta.
2. Abra a aba **Actions** → "Gerar APK" (roda sozinho a cada push, ou em *Run workflow*).
3. Ao terminar, baixe o artefato **Nebula-APK** e instale no celular.

### Opção B — Android Studio
1. Abra a pasta `NebulaHub` no Android Studio (Ladybug ou mais novo).
2. *Build → Build App Bundle(s) / APK(s) → Build APK(s)*, ou conecte o celular e clique em ▶.

Requisitos: Android 8.0 ou mais novo.

## Primeiro uso (permissões)

1. **Sobrepor a outros apps** — para o pop-up (o app pede na primeira vez que você tocar no botão de pop-up).
2. **Acesso a notificações** — para ver e controlar a música do Spotify (toque em "Conectar ao Spotify").
   - No **Android 13+**, apps instalados por APK podem ter essa opção bloqueada. Para liberar: *Configurações → Apps → Nebula → ⋮ (canto superior) → Permitir configurações restritas*, e depois ative o acesso.

## Estrutura

```
app/src/main/java/com/nebula/hub/
  MainActivity.kt        tela principal (jogos + player)
  Games.kt               detecção de jogos e grade
  MediaHelper.kt         controle do Spotify via MediaSession
  PlayerViews.kt         controles de música (compartilhados com o pop-up)
  OverlayService.kt      bolha + painel translúcido
  OverlayTileService.kt  bloco das Configurações Rápidas
  ToggleActivity.kt      liga/desliga o pop-up sem abrir o app
  MediaListener.kt       permissão de mídia (se desliga sozinho)
  Spotify.kt / Util.kt   utilidades
```
