package com.nebula.hub

import android.app.Activity
import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import android.widget.Toast
import java.text.Normalizer

/**
 * Recebe pedidos do A.I.V.A.D. por links "nebula://aivad/...".
 * Atividade invisível: executa o pedido e fecha na hora. Nada fica rodando depois.
 *
 *   nebula://aivad/musica?acao=tocar|pausar|alternar|proxima|anterior
 *   nebula://aivad/volume?acao=aumentar|diminuir|mudo   ou   ?nivel=0..100
 *   nebula://aivad/playlist?nome=jogo        (playlists salvas no Nebula; "curtidas" também vale)
 *   nebula://aivad/buscar?q=linkin park       (o Spotify toca o resultado da busca)
 *   nebula://aivad/jogo?nome=free fire&playlist=jogo
 *   nebula://aivad/popup?acao=abrir|fechar|alternar
 *
 * Parâmetro opcional: voltar=https://... (para onde voltar depois que a música começar).
 */
class AivadActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dados = intent?.data
        if (dados != null && dados.scheme == "nebula" && dados.host == "aivad") {
            try {
                executar(dados)
            } catch (e: Exception) {
                avisar("Nebula: não consegui fazer isso.")
            }
        }
        finish()
    }

    private fun executar(d: Uri) {
        when (d.path?.trim('/')) {
            "musica" -> musica(d.getQueryParameter("acao").orEmpty())
            "volume" -> volume(d.getQueryParameter("acao").orEmpty(), d.getQueryParameter("nivel"))
            "playlist" -> playlist(d.getQueryParameter("nome").orEmpty(), voltarPara(d))
            "buscar" -> buscar(d.getQueryParameter("q").orEmpty(), voltarPara(d))
            "jogo" -> jogo(d.getQueryParameter("nome").orEmpty(), d.getQueryParameter("playlist"))
            "popup" -> popup(d.getQueryParameter("acao").orEmpty())
            else -> avisar("Nebula: pedido desconhecido.")
        }
    }

    // ---------- Música (teclas de mídia: funciona com qualquer player, sem Premium) ----------

    private fun musica(acao: String) {
        val codigo = when (normalizar(acao)) {
            "tocar", "play", "continuar" -> KeyEvent.KEYCODE_MEDIA_PLAY
            "pausar", "pause", "parar" -> KeyEvent.KEYCODE_MEDIA_PAUSE
            "proxima", "pular", "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "anterior", "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        }
        val audio = getSystemService(AudioManager::class.java)
        val t = SystemClock.uptimeMillis()
        audio.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, codigo, 0))
        audio.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, codigo, 0))
    }

    private fun volume(acao: String, nivel: String?) {
        val audio = getSystemService(AudioManager::class.java)
        val stream = AudioManager.STREAM_MUSIC
        val porcento = nivel?.toIntOrNull()
        if (porcento != null) {
            val max = audio.getStreamMaxVolume(stream)
            audio.setStreamVolume(stream, (max * porcento.coerceIn(0, 100) + 50) / 100, AudioManager.FLAG_SHOW_UI)
            return
        }
        val direcao = when (normalizar(acao)) {
            "aumentar", "mais", "subir" -> AudioManager.ADJUST_RAISE
            "diminuir", "menos", "baixar" -> AudioManager.ADJUST_LOWER
            "mudo", "silenciar" -> AudioManager.ADJUST_TOGGLE_MUTE
            else -> return
        }
        // Dois passos por pedido, para a diferença ser perceptível
        val passos = if (direcao == AudioManager.ADJUST_TOGGLE_MUTE) 1 else 2
        repeat(passos) { audio.adjustStreamVolume(stream, direcao, AudioManager.FLAG_SHOW_UI) }
    }

    // ---------- Playlists e busca ----------

    private fun playlist(nome: String, voltar: Intent?) {
        val alvo = normalizar(nome)
        val curtidas = Playlist(PlaylistStore.LIKED_URI, getString(R.string.liked_songs), null)
        val escolhida: Playlist? = PlaylistStore.parse(nome)?.let { Playlist(it, nome, null) }
            ?: if (alvo in NOMES_CURTIDAS) curtidas
            else melhor(listOf(curtidas) + PlaylistStore.all(this), alvo) { it.name }
        if (escolhida == null) {
            avisar("Nebula: não achei a playlist \"$nome\".")
            return
        }
        avisar("▶ ${escolhida.name}")
        Spotify.play(applicationContext, escolhida.uri, voltar)
    }

    private fun buscar(busca: String, voltar: Intent?) {
        if (busca.isBlank()) return
        val i = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
            .setPackage(Spotify.PKG)
            .putExtra(SearchManager.QUERY, busca)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
        if (!iniciar(i)) {
            Spotify.open(applicationContext)
            return
        }
        avisar("🔎 $busca")
        if (voltar != null) Bg.main.postDelayed({ iniciar(voltar) }, VOLTA_MS)
    }

    // ---------- Jogos ----------

    private fun jogo(nome: String, playlistNome: String?) {
        val app = applicationContext
        val lista = GameRepository.load(app)
        val alvo = normalizar(nome)
        val g = melhor(lista.games, alvo) { it.label } ?: melhor(lista.others, alvo) { it.label }
        if (g == null) {
            avisar("Nebula: não achei o jogo \"$nome\".")
            return
        }
        val abrir = packageManager.getLaunchIntentForPackage(g.pkg)
        if (abrir == null) {
            avisar(getString(R.string.cannot_launch))
            return
        }
        abrir.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        Prefs.markPlayed(app, g.pkg)
        Prefs.setLastGame(app, g.pkg)
        if (Prefs.autoPopup(app) && Settings.canDrawOverlays(app) && !OverlayService.isRunning) {
            OverlayService.start(app)
        }
        if (!playlistNome.isNullOrBlank()) {
            // Começa a música e, logo depois, abre o jogo
            playlist(playlistNome, abrir)
        } else {
            avisar("🎮 ${g.label}")
            iniciar(abrir)
        }
    }

    // ---------- Pop-up ----------

    private fun popup(acao: String) {
        if (!Settings.canDrawOverlays(this)) {
            iniciar(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        }
        when (normalizar(acao)) {
            "abrir", "ligar", "mostrar" -> if (!OverlayService.isRunning) OverlayService.start(this)
            "fechar", "desligar", "esconder" -> OverlayService.stop(this)
            else -> OverlayService.toggle(this)
        }
    }

    // ---------- Utilidades ----------

    /** Volta para o app que fez o pedido (o A.I.V.A.D. instalado pelo Chrome) ou para o link "voltar". */
    private fun voltarPara(d: Uri): Intent? {
        val pacote = referrer?.takeIf { it.scheme == "android-app" }?.host
        if (pacote != null && pacote.startsWith("org.chromium.webapk")) {
            packageManager.getLaunchIntentForPackage(pacote)?.let {
                return it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
            }
        }
        val url = d.getQueryParameter("voltar") ?: return null
        if (!url.startsWith("https://")) return null
        return Intent(Intent.ACTION_VIEW, Uri.parse(url))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
    }

    private fun iniciar(i: Intent): Boolean = try {
        applicationContext.startActivity(i)
        true
    } catch (e: ActivityNotFoundException) {
        false
    } catch (e: SecurityException) {
        false
    }

    private fun avisar(texto: String) {
        Toast.makeText(applicationContext, texto, Toast.LENGTH_SHORT).show()
    }

    /** Escolhe o item cujo nome mais combina com o pedido (sem acento, sem maiúsculas). */
    private fun <T> melhor(itens: List<T>, alvo: String, nome: (T) -> String): T? {
        if (alvo.isBlank()) return null
        val palavras = alvo.split(' ').filter { it.length > 1 }
        var escolhido: T? = null
        var maior = 0
        for (item in itens) {
            val n = normalizar(nome(item))
            val pontos = when {
                n == alvo -> 100
                n.startsWith(alvo) -> 80
                n.contains(alvo) -> 60
                n.length >= 3 && alvo.contains(n) -> 50
                else -> palavras.count { n.contains(it) } * 10
            }
            if (pontos > maior) {
                maior = pontos
                escolhido = item
            }
        }
        return escolhido
    }

    private fun normalizar(texto: String): String {
        val semAcento = Normalizer.normalize(texto, Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")
        return semAcento.lowercase().replace(Regex("[^a-z0-9]+"), " ").trim()
    }

    private companion object {
        const val VOLTA_MS = 1500L
        val NOMES_CURTIDAS = setOf("curtidas", "musicas curtidas", "minhas curtidas", "favoritas", "favoritos")
    }
}
