package com.nebula.hub

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.SystemClock
import android.provider.Settings
import android.view.KeyEvent

/**
 * Controla o Spotify (ou o player ativo) via MediaSession do próprio Android.
 *
 * - Não precisa de conta de desenvolvedor do Spotify nem de SDK externo.
 * - 100% orientado a eventos: nenhuma consulta periódica (polling).
 * - Só escuta enquanto alguma tela está visível (start/stop). Em segundo plano: zero trabalho.
 */
class MediaHelper(context: Context, private val onUpdate: (State) -> Unit) {

    data class State(
        val hasAccess: Boolean,
        val title: String? = null,
        val artist: String? = null,
        val art: Bitmap? = null,
        val playing: Boolean = false,
        val isSpotify: Boolean = false,
    )

    private val ctx = context.applicationContext
    private val msm = ctx.getSystemService(MediaSessionManager::class.java)
    private val audio = ctx.getSystemService(AudioManager::class.java)
    private val listener = ComponentName(ctx, MediaListener::class.java)
    private var controller: MediaController? = null
    private var started = false
    private var lastState: State? = null

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = publish()
        override fun onPlaybackStateChanged(state: PlaybackState?) = publish()
        override fun onSessionDestroyed() {
            bind(null)
        }
    }

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> pick(list) }

    fun hasAccess(): Boolean {
        val enabled = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners")
        return enabled?.contains(listener.flattenToString()) == true ||
            enabled?.contains(listener.flattenToShortString()) == true
    }

    fun start() {
        if (started) return
        started = true
        lastState = null
        if (!hasAccess()) {
            onUpdate(State(hasAccess = false))
            return
        }
        try {
            msm.addOnActiveSessionsChangedListener(sessionsListener, listener, Bg.main)
            pick(msm.getActiveSessions(listener))
        } catch (e: SecurityException) {
            onUpdate(State(hasAccess = false))
        }
    }

    fun stop() {
        if (!started) return
        started = false
        try {
            msm.removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (_: Exception) {
        }
        controller?.unregisterCallback(callback)
        controller = null
        lastState = null
    }

    private fun pick(list: List<MediaController>?) {
        if (!started) return
        val c = list?.firstOrNull { it.packageName == Spotify.PKG }
            ?: list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list?.firstOrNull()
        bind(c)
    }

    private fun bind(c: MediaController?) {
        val old = controller
        if (c != null && old != null && c.sessionToken == old.sessionToken) {
            publish()
            return
        }
        old?.unregisterCallback(callback)
        controller = c
        c?.registerCallback(callback, Bg.main)
        publish()
    }

    private fun publish() {
        if (!started) return
        val c = controller
        val s = if (c == null) State(hasAccess = true) else {
            val m = c.metadata
            val st = c.playbackState?.state
            State(
                hasAccess = true,
                title = m?.getString(MediaMetadata.METADATA_KEY_TITLE),
                artist = m?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                    ?: m?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST),
                art = m?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                    ?: m?.getBitmap(MediaMetadata.METADATA_KEY_ART)
                    ?: m?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON),
                playing = st == PlaybackState.STATE_PLAYING || st == PlaybackState.STATE_BUFFERING,
                isSpotify = c.packageName == Spotify.PKG,
            )
        }
        if (s == lastState) return   // evita redesenhar a tela à toa
        lastState = s
        onUpdate(s)
    }

    fun playPause() {
        val c = controller
        if (c == null) {
            // Sem sessão ativa: manda a tecla "play" para o último player usado (normalmente o Spotify).
            sendKey(KeyEvent.KEYCODE_MEDIA_PLAY)
            return
        }
        val st = c.playbackState?.state
        if (st == PlaybackState.STATE_PLAYING || st == PlaybackState.STATE_BUFFERING) {
            c.transportControls.pause()
        } else {
            c.transportControls.play()
        }
    }

    fun next() {
        controller?.transportControls?.skipToNext() ?: sendKey(KeyEvent.KEYCODE_MEDIA_NEXT)
    }

    fun previous() {
        controller?.transportControls?.skipToPrevious() ?: sendKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
    }

    private fun sendKey(code: Int) {
        val t = SystemClock.uptimeMillis()
        audio.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0))
        audio.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0))
    }
}
