package com.nebula.hub

import android.content.res.ColorStateList
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView

/** Liga os mesmos controles de música na tela principal e no pop-up. */
class PlayerViews(root: View, media: MediaHelper) {
    private val ctx = root.context
    private val art: ImageView = root.findViewById<ImageView>(R.id.art)
    private val title: TextView = root.findViewById<TextView>(R.id.title)
    private val artist: TextView = root.findViewById<TextView>(R.id.artist)
    private val play: ImageButton = root.findViewById<ImageButton>(R.id.btn_play)
    private val placeholderTint: ColorStateList? = art.imageTintList
    private val placeholderPad = art.paddingTop
    private var showingArt = false

    init {
        art.clipToOutline = true // cantos arredondados na capa (o atributo XML só existe no Android 12+)
        root.findViewById<View>(R.id.btn_prev).setOnClickListener { media.previous() }
        root.findViewById<View>(R.id.btn_next).setOnClickListener { media.next() }
        play.setOnClickListener { media.playPause() }
    }

    fun render(s: MediaHelper.State) {
        title.text = s.title ?: ctx.getString(
            if (s.hasAccess) R.string.nothing_playing else R.string.media_access_title
        )
        artist.text = s.artist ?: ctx.getString(R.string.tap_to_open_spotify)
        play.setImageResource(if (s.playing) R.drawable.ic_pause else R.drawable.ic_play)

        val bmp = s.art
        if (bmp != null) {
            art.imageTintList = null
            art.setPadding(0, 0, 0, 0)
            art.setImageBitmap(bmp)
            showingArt = true
        } else if (showingArt) {
            clearArt()
        }
    }

    /** Volta ao ícone padrão e solta a referência ao bitmap da capa (libera memória). */
    fun clearArt() {
        art.imageTintList = placeholderTint
        art.setPadding(placeholderPad, placeholderPad, placeholderPad, placeholderPad)
        art.setImageResource(R.drawable.ic_music)
        showingArt = false
    }
}
