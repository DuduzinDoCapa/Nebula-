package com.nebula.hub

import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore

object Spotify {
    const val PKG = "com.spotify.music"

    /** Abre o Spotify; se não estiver instalado, abre a página dele na Play Store. */
    fun open(ctx: Context) {
        val launch = ctx.packageManager.getLaunchIntentForPackage(PKG)
        if (launch != null) {
            start(ctx, launch)
        } else {
            openStore(ctx)
        }
    }

    /** Abre uma tela específica do Spotify (ex.: "spotify:collection:tracks" = Músicas Curtidas). */
    fun openUri(ctx: Context, uri: String) {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(uri)).setPackage(PKG)
        if (!start(ctx, i)) open(ctx)
    }

    /**
     * Toca uma playlist/álbum. O Spotify ignora pedidos de outros apps pela sessão de mídia,
     * então usamos o comando "tocar a partir de busca" (o mesmo de NFC/Tasker), que abre o
     * Spotify por um instante. Depois de [RETURN_DELAY_MS], [comeBack] traz de volta a tela
     * anterior (o Nebula ou o jogo), enquanto a música continua tocando.
     */
    fun play(ctx: Context, uri: String, comeBack: Intent?) {
        val i = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
            .setData(Uri.parse("$uri:play"))
            .setPackage(PKG)
            .putExtra(SearchManager.QUERY, "")
            .addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
        if (!start(ctx, i)) {
            openUri(ctx, uri)
            return
        }
        if (comeBack != null) {
            Bg.main.postDelayed({ start(ctx, comeBack) }, RETURN_DELAY_MS)
        }
    }

    private const val RETURN_DELAY_MS = 1500L

    private fun openStore(ctx: Context) {
        if (!start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$PKG")))) {
            start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$PKG")))
        }
    }

    private fun start(ctx: Context, i: Intent): Boolean = try {
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: ActivityNotFoundException) {
        false
    } catch (e: SecurityException) {
        false
    }
}
