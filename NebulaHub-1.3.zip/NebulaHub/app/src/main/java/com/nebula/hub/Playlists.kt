package com.nebula.hub

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class Playlist(val uri: String, val name: String, val image: String?)

/**
 * Playlists favoritas salvas no aparelho.
 * Sem Spotify Premium não existe API para listar a biblioteca, então o usuário
 * adiciona cada uma uma vez (compartilhando do Spotify ou colando o link).
 * Nome e capa vêm do endpoint público oEmbed do Spotify (não precisa de login).
 */
object PlaylistStore {
    const val LIKED_URI = "spotify:collection:tracks"
    private const val KEY = "playlists"
    private val RX = Regex("(playlist|album|artist|show|episode|track)[/:]([A-Za-z0-9]{22})")

    private fun sp(c: Context) = c.getSharedPreferences("nebula", Context.MODE_PRIVATE)

    fun parse(text: String): String? =
        RX.find(text)?.let { "spotify:${it.groupValues[1]}:${it.groupValues[2]}" }

    fun all(c: Context): List<Playlist> {
        val arr = try {
            JSONArray(sp(c).getString(KEY, "[]"))
        } catch (e: Exception) {
            JSONArray()
        }
        val out = ArrayList<Playlist>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out += Playlist(o.optString("uri"), o.optString("name"), o.optString("image").ifEmpty { null })
        }
        return out
    }

    private fun save(c: Context, list: List<Playlist>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("uri", it.uri).put("name", it.name).put("image", it.image ?: ""))
        }
        sp(c).edit().putString(KEY, arr.toString()).apply()
    }

    fun remove(c: Context, uri: String) {
        all(c).firstOrNull { it.uri == uri }?.image?.let { File(it).delete() }
        save(c, all(c).filterNot { it.uri == uri })
        IconCache.remove("pl:$uri")
    }

    /** Resolve o texto (link/URI), busca nome e capa e salva. [done] roda na thread principal. */
    fun resolveAndAdd(ctx: Context, text: String, done: (Playlist?) -> Unit) {
        val app = ctx.applicationContext
        Bg.run {
            val uri = parse(text) ?: resolveShortLink(text)
            val p = uri?.let { fetchMeta(app, it) }
            if (p != null) save(app, all(app).filterNot { it.uri == p.uri } + p)
            Bg.ui { done(p) }
        }
    }

    /** Links curtos (spotify.link/...) redirecionam para open.spotify.com. */
    private fun resolveShortLink(text: String): String? {
        var url = Regex("https?://\\S*spotify\\.link/\\S+").find(text)?.value ?: return null
        repeat(5) {
            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = false
                connectTimeout = 8000; readTimeout = 8000
            }
            try {
                val loc = conn.getHeaderField("Location") ?: return null
                parse(loc)?.let { return it }
                url = loc
            } catch (e: Exception) {
                return null
            } finally {
                conn.disconnect()
            }
        }
        return null
    }

    private fun fetchMeta(ctx: Context, uri: String): Playlist {
        val (_, type, id) = uri.split(":")
        var name = ctx.getString(R.string.playlist_default_name)
        var image: String? = null
        try {
            val target = URLEncoder.encode("https://open.spotify.com/$type/$id", "UTF-8")
            val json = JSONObject(httpGet("https://open.spotify.com/oembed?url=$target").toString(Charsets.UTF_8))
            json.optString("title").takeIf { it.isNotBlank() }?.let { name = it }
            json.optString("thumbnail_url").takeIf { it.isNotBlank() }?.let { image = saveThumb(ctx, id, it) }
        } catch (_: Exception) {
            // Sem internet: salva mesmo assim, com nome genérico
        }
        return Playlist(uri, name, image)
    }

    private fun saveThumb(ctx: Context, id: String, url: String): String? = try {
        val bytes = httpGet(url)
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
        var sample = 1
        while (opts.outWidth / (sample * 2) >= 160) sample *= 2
        val raw = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
        val bmp = Bitmap.createScaledBitmap(raw, 160, 160, true)
        val f = File(ctx.filesDir, "pl_$id.jpg")
        FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        f.absolutePath
    } catch (e: Exception) {
        null
    }

    private fun httpGet(url: String): ByteArray {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 8000; readTimeout = 8000
            setRequestProperty("User-Agent", "Nebula/1.1")
        }
        try {
            return conn.inputStream.use { it.readBytes() }
        } finally {
            conn.disconnect()
        }
    }
}

/** Fileira horizontal de playlists (usada na tela principal e no pop-up). */
class PlaylistViews(
    root: View,
    private val imageDp: Int,
    private val onPlay: (Playlist) -> Unit,
    private val onLongPress: ((Playlist) -> Unit)? = null,
) {
    private val ctx = root.context
    private val row: LinearLayout = root.findViewById<LinearLayout>(R.id.playlist_row)
    private val empty: View = root.findViewById<View>(R.id.playlist_empty)

    fun refresh() {
        val list = listOf(Playlist(PlaylistStore.LIKED_URI, ctx.getString(R.string.liked_songs), null)) +
            PlaylistStore.all(ctx)
        row.removeAllViews()
        empty.visibility = if (list.size <= 1) View.VISIBLE else View.GONE
        val inf = LayoutInflater.from(ctx)
        val px = ctx.dp(imageDp)
        for (p in list) {
            val v = inf.inflate(R.layout.item_playlist, row, false)
            v.layoutParams.width = px + ctx.dp(14)
            val img = v.findViewById<ImageView>(R.id.pl_image)
            img.layoutParams.width = px
            img.layoutParams.height = px
            img.clipToOutline = true
            v.findViewById<TextView>(R.id.pl_name).text = p.name
            if (p.uri == PlaylistStore.LIKED_URI) img.setImageResource(R.drawable.ic_heart) else loadThumb(img, p)
            v.setOnClickListener { onPlay(p) }
            if (onLongPress != null && p.uri != PlaylistStore.LIKED_URI) {
                v.setOnLongClickListener { onLongPress.invoke(p); true }
            }
            row.addView(v)
        }
    }

    private fun loadThumb(img: ImageView, p: Playlist) {
        val path = p.image ?: return
        val key = "pl:${p.uri}"
        IconCache.get(key)?.let { showThumb(img, it); return }
        img.tag = key
        Bg.run {
            val bmp = BitmapFactory.decodeFile(path)
            if (bmp != null) IconCache.put(key, bmp)
            Bg.ui { if (bmp != null && img.tag == key) showThumb(img, bmp) }
        }
    }

    private fun showThumb(img: ImageView, bmp: Bitmap) {
        img.imageTintList = null
        img.setPadding(0, 0, 0, 0)
        img.setImageBitmap(bmp)
    }
}
