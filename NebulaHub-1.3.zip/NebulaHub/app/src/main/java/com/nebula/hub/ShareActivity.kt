package com.nebula.hub

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast

/**
 * Recebe "Compartilhar" do Spotify: Playlist → ⋯ → Compartilhar → Nebula.
 * Não mostra tela nenhuma; só adiciona e avisa com um toast.
 */
class ShareActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = if (intent?.action == Intent.ACTION_SEND) intent.getStringExtra(Intent.EXTRA_TEXT) else null
        val app = applicationContext
        if (text.isNullOrBlank()) {
            Toast.makeText(app, R.string.playlist_invalid, Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(app, R.string.playlist_adding, Toast.LENGTH_SHORT).show()
            PlaylistStore.resolveAndAdd(app, text) { p ->
                val msg = if (p == null) app.getString(R.string.playlist_invalid)
                else app.getString(R.string.playlist_added, p.name)
                Toast.makeText(app, msg, Toast.LENGTH_SHORT).show()
            }
        }
        finish()
    }
}
