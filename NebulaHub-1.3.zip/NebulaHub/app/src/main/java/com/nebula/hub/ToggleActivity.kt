package com.nebula.hub

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings

/** Atividade invisível usada pelo atalho do ícone e pelo bloco rápido para ligar/desligar o pop-up. */
class ToggleActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Settings.canDrawOverlays(this)) {
            OverlayService.toggle(this)
        } else {
            startActivity(Intent(this, MainActivity::class.java))
        }
        finish()
    }
}
