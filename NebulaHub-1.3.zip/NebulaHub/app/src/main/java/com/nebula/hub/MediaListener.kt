package com.nebula.hub

import android.service.notification.NotificationListenerService

/**
 * O Android só deixa um app ler/controlar a música tocando (MediaSession) se ele
 * tiver "Acesso a notificações". Este serviço existe apenas para isso.
 *
 * Ele não lê nenhuma notificação: assim que o sistema conecta, pedimos para
 * ser desconectado. A permissão continua concedida, mas o processo do app não
 * fica preso na memória por causa deste serviço — economia de RAM e bateria.
 */
class MediaListener : NotificationListenerService() {
    override fun onListenerConnected() {
        super.onListenerConnected()
        try {
            requestUnbind()
        } catch (_: Exception) {
        }
    }
}
