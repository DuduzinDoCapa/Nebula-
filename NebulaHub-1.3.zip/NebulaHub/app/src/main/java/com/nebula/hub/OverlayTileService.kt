package com.nebula.hub

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/**
 * Bloco nas Configurações Rápidas: puxe a barra de notificações durante o jogo
 * e toque em "Pop-up Nebula". Não roda nada em segundo plano — o sistema só o
 * chama quando a barra está aberta.
 */
class OverlayTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        render(OverlayService.isRunning)
    }

    override fun onClick() {
        super.onClick()
        when {
            !Settings.canDrawOverlays(this) -> openActivity(Intent(this, MainActivity::class.java))
            OverlayService.isRunning -> {
                OverlayService.stop(this)
                render(false)
            }
            OverlayService.start(this) -> render(true)
            // Se o Android bloquear o início direto, usa a atividade invisível
            else -> openActivity(Intent(this, ToggleActivity::class.java))
        }
    }

    private fun render(active: Boolean) {
        val t = qsTile ?: return
        t.state = if (active) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.updateTile()
    }

    private fun openActivity(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) {
            val pi = PendingIntent.getActivity(
                this, 0, i,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            startActivityAndCollapse(pi)
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(i)
        }
    }
}
