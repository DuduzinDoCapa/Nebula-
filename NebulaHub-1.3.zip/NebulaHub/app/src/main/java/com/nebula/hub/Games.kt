package com.nebula.hub

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.os.Build
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView

data class Game(val pkg: String, val label: String, val lastPlayed: Long)

object GameRepository {

    class Result(val games: List<Game>, val others: List<Game>)

    /** Lista apps com ícone na tela inicial e separa os jogos (detectados + adicionados). */
    fun load(ctx: Context): Result {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val infos: List<ResolveInfo> = if (Build.VERSION.SDK_INT >= 33) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0L))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(intent, 0)
        }
        val added = Prefs.added(ctx)
        val hidden = Prefs.hidden(ctx)
        val seen = HashSet<String>()
        val games = ArrayList<Game>()
        val others = ArrayList<Game>()

        for (ri in infos) {
            val ai = ri.activityInfo?.applicationInfo ?: continue
            val pkg = ai.packageName
            if (pkg == ctx.packageName || !seen.add(pkg)) continue
            val g = Game(pkg, ri.loadLabel(pm).toString(), Prefs.lastPlayed(ctx, pkg))
            if ((isGame(ai) && pkg !in hidden) || pkg in added) games += g else others += g
        }
        // Jogados recentemente primeiro, depois em ordem alfabética
        games.sortWith(compareByDescending<Game> { it.lastPlayed }.thenBy { it.label.lowercase() })
        others.sortBy { it.label.lowercase() }
        return Result(games, others)
    }

    @Suppress("DEPRECATION")
    private fun isGame(ai: ApplicationInfo) =
        ai.category == ApplicationInfo.CATEGORY_GAME || (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
}

class GameAdapter(private val ctx: Context) : BaseAdapter() {
    private var items: List<Game> = emptyList()
    private val inflater = LayoutInflater.from(ctx)
    private val iconPx = ctx.dp(48)

    fun submit(list: List<Game>) {
        items = list
        notifyDataSetChanged()
    }

    override fun getCount() = items.size
    override fun getItem(position: Int): Game = items[position]
    override fun getItemId(position: Int) = items[position].pkg.hashCode().toLong()
    override fun hasStableIds() = true

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val v = convertView ?: inflater.inflate(R.layout.item_game, parent, false).also {
            it.tag = Holder(it.findViewById<ImageView>(R.id.icon), it.findViewById<TextView>(R.id.label))
        }
        val h = v.tag as Holder
        val g = items[position]
        h.label.text = g.label
        h.pkg = g.pkg

        val cached = IconCache.get(g.pkg)
        if (cached != null) {
            h.icon.setImageBitmap(cached)
        } else {
            h.icon.setImageDrawable(null)
            val app = ctx.applicationContext
            val pkg = g.pkg
            Bg.run {
                val bmp = IconCache.load(app, pkg, iconPx)
                Bg.ui { if (h.pkg == pkg && bmp != null) h.icon.setImageBitmap(bmp) }
            }
        }
        return v
    }

    private class Holder(val icon: ImageView, val label: TextView) {
        var pkg: String? = null
    }
}
