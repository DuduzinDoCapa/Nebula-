# Componentes declarados no manifesto já são mantidos automaticamente pelo AAPT.
# Nenhuma regra extra necessária.
